
export class Book {
    _id:String;
    category:String;
    name:String;
    url: String;
    description:String;
    actor:String;
    price:number;
}
    