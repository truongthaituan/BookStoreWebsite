import { Component, OnInit,EventEmitter, SystemJsNgModuleLoader } from '@angular/core';
import {AuthService,SocialUser, GoogleLoginProvider,FacebookLoginProvider} from 'ng4-social-login';
import { UserService } from '../shared/user.service';
import { NgForm } from '@angular/forms';
import {User} from '../shared/user.model';
import { print } from 'util';
// import { getMaxListeners } from 'cluster';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers: [UserService],
  outputs:['loginEvent']
})
export class LoginComponent implements OnInit {
  public user : any = SocialUser;
  loginEvent= new EventEmitter();
  loginsuccessed = localStorage.getItem('loginsuccess');

  constructor(private socialAuthService: AuthService, 
              private userService: UserService) {}






              
  facebooklogin(){
    this.socialAuthService.signIn(FacebookLoginProvider.PROVIDER_ID).then((userData) =>{
      this.user = userData;
       localStorage.setItem('ImgUrlsession',this.user.photoUrl);
       localStorage.setItem('Namesession',this.user.name);
       localStorage.setItem('idlogin_regis',this.user.id);    

      window.location.reload();
     
      localStorage.setItem('loginsuccess',"1");
    });
     
     
  }

  googlelogin(){
    this.socialAuthService.signIn(GoogleLoginProvider.PROVIDER_ID).then((userData) =>{
      this.user =userData;
      localStorage.setItem('ImgUrlsession',this.user.photoUrl);
      localStorage.setItem('Namesession',this.user.name);
      localStorage.setItem('idlogin_regis',this.user.id);   
      
      window.location.reload();
      localStorage.setItem('loginsuccess',"1");
    });
  }
  ngOnInit() {

  }


  emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  showSucessMessage: boolean;
  serverErrorMessages: string;
  
  onSubmit(form: NgForm) {
    
    
    
    this.userService.loginUser(form.value).subscribe(
      res => {
        localStorage.setItem('ImgUrlsession',"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQgdQWFnbv_9jTfXovgbCWW9v8-Wuaekr6awTB2y0JY_TqoQaiEbA&s");
        localStorage.setItem('Namesession',res[0]);
        localStorage.setItem('IdUserLogin',res[1]);
    
        window.location.reload();
    
        localStorage.setItem('loginsuccess',"1");
      },
      err => {
        if (err.status === 500) {
          this.serverErrorMessages = err.error.join('<br/>');
        }
        if (err.status === 404) {
          this.serverErrorMessages = err.error.join('<br/>');
        }
        if (err.status === 200) {
          this.serverErrorMessages = err.error.join('<br/>');
        }
      }
    );
  }


  


  resetForm(form: NgForm) {
    this.userService.selectedUser = {
      _id:'',
      fullName: '',
      email: '',
      password: ''
  
    };
    form.resetForm();
    this.serverErrorMessages = '';
  }
  
}
