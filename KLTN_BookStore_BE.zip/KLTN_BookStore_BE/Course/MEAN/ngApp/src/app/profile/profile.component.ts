import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

import { UserService } from '../shared/user.service';
import { User } from '../shared/user.model';
import { format } from 'url';
import { delay } from 'q';
@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css'],
  providers: [UserService]
})

export class ProfileComponent implements OnInit {
  user :  "";
  IDLoginLocal=localStorage.getItem('IdUserLogin');
  IDLoginFB=localStorage.getItem('idlogin_regis');
  emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  showSucessMessage: boolean;
  serverErrorMessages: string;
 

  constructor(private userService: UserService) { }

  ngOnInit() {
      this.IDLoginLocal=localStorage.getItem('IdUserLogin');
      console.log(this.IDLoginLocal);
      this.userService.GetUser(this.IDLoginLocal)
      .subscribe(resUser => { 
      this.user = resUser;
      // console.log(this.user);
    });
   
   
  }

   form:NgForm;
  UpdateUser(user: User) {
    
    this.userService.GetUser(this.IDLoginLocal)
    .subscribe(resUser => { 
    this.user = resUser;
 
    // this.form.value.password1=user.
    user.fullName=resUser.fullName;
    user.email=resUser.email;
    user._id=localStorage.getItem('IdUserLogin');
    this.userService.UpdateUser(user).subscribe(
      res => {
        this.showSucessMessage = true;
        setTimeout(() => this.showSucessMessage = false, 4000);

      },
      err => {
        if (err.status === 422) {
          this.serverErrorMessages = err.error.join('<br/>');
        }
        else
          this.serverErrorMessages = ('Something went wrong.Please contact admin.');
      }
    );
  }
  
  );

    }
  
}
