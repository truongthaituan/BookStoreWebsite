import { Component } from '@angular/core';
import { UserService } from './shared/user.service'
import { User } from './shared/user.model';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [UserService]
})
export class AppComponent {

  title = 'ABC';
  name =localStorage.getItem('Namesession');
  imgUrl =localStorage.getItem('ImgUrlsession');
  showSucessMessage=false;
  serverErrorMessages="";
  IDLoginFB=localStorage.getItem('idlogin_regis');
  
  IDLoginLocal=localStorage.getItem('IdUserLogin');
  
  user:Array<User>;
  constructor(private userService: UserService) { }
  
 



 
  
  logout(){
    localStorage.clear();
    window.location.reload();
  }
}
