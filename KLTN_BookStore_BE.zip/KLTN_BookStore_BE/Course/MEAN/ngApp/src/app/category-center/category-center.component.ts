import { Component, OnInit } from '@angular/core';
import { Category } from '../shared/category.model';
import { CategoryService } from '../shared/category.service';
@Component({
  selector: 'category-center',
  templateUrl: './category-center.component.html',
  styleUrls: ['./category-center.component.css'],
  providers:[CategoryService]
})
export class CategoryCenterComponent implements OnInit {

  categories: Array<Category>;
  selectedCategory:Category;
  hidenewCategory:boolean =true;
  constructor(private _categoryService:CategoryService) { }
  updateoke=false
  deleteoke=false
 
  ngOnInit() {
    this._categoryService.getCategories()
    .subscribe(resCategoryData => {console.log(resCategoryData);this.categories = resCategoryData});

  }

  onSelectCategory(category:any){
    this.selectedCategory=category;
    this.hidenewCategory=true;
    console.log(this.selectedCategory);
    this.updateoke=false
    this.deleteoke=false
  }
  onSubmitAddCategory(category:Category){
    this._categoryService.addCategory(category)
    .subscribe(resNewCategory =>{
      this.categories.push(resNewCategory);
      this.selectedCategory=resNewCategory;
      this.hidenewCategory=true;
    });
  }
  onUpdateCategoryEvent(category:any){
    this._categoryService.updateCategory(category)
    .subscribe(resUpdateCategory => category = resUpdateCategory);
    this.selectedCategory  = null;
    this.updateoke=true
  }

  onDeleteCategoryEvent(category:any){
    let categoryArray=this.categories;
    this._categoryService.delete(category)
    .subscribe(resDeletedCategory =>{
      for(let i=0;i<categoryArray.length;i++)
      {
        if(categoryArray[i]._id === category._id){
          categoryArray.splice(i,1);
        }
      }
    });
    this.selectedCategory=null;
    this.deleteoke=true
  }
  newCategory(){
    this.hidenewCategory=false;
    this.updateoke=false
    this.deleteoke=false
  }
}
