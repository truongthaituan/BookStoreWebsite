import { Component, OnInit ,EventEmitter} from '@angular/core';
import { Book } from '../book';
@Component({
  selector: 'book-list',
  templateUrl: './book-list.component.html',
  styleUrls: ['./book-list.component.css'],
  inputs:['books'],
  outputs:['SelectBook']
})
export class BookListComponent implements OnInit {

  public SelectBook = new EventEmitter();
  constructor() { }

  ngOnInit() {
  }

  onSelect(vid: Book){
    this.SelectBook.emit(vid);
    
  }

}
