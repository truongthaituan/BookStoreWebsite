import { Component, OnInit } from '@angular/core';
import { BookService } from '../book.service';
import { UserService } from '../shared/user.service';
import { Book } from '../book';
import { User_Book } from '../shared/user_book.model';
import { Router, NavigationExtras } from '@angular/router';
import { CategoryService } from '../shared/category.service';
import { Category } from '../shared/category.model';
@Component({
  selector: 'app-buy-book',
  templateUrl: './buy-book.component.html',
  styleUrls: ['./buy-book.component.css'],
  providers:[BookService,CategoryService],
  // template: `{{ now }}`

})
export class BuyBookComponent implements OnInit {
 

  bookdetail = localStorage.getItem('book_detail');

  IdLogin=null;
  messfail=false;
  


  book: "";
  categories: Array<Category>;
  user_books: Array<User_Book>;
  showSucessMessage: boolean;
  constructor(private _bookService:BookService,private _userService:UserService,private _router:Router,private _categoryService:CategoryService) { }

  ngOnInit() {
    this.bookdetail =localStorage.getItem('book_detail');
    if(localStorage.getItem('IdUserLogin'))
    this.IdLogin =localStorage.getItem('IdUserLogin');
    else
    this.IdLogin =localStorage.getItem('idlogin_regis');
    this._bookService.getBookById(this.bookdetail)
    .subscribe(resBookData => {console.log(resBookData);this.book = resBookData;
      this._categoryService.getCategories()
      .subscribe(resCategoryData => {console.log(resCategoryData);this.categories = resCategoryData});
    });
  
  }

  onSubmitBuyBook(user_book:User_Book){
    
    if(localStorage.getItem('IdUserLogin'))
    this.IdLogin =localStorage.getItem('IdUserLogin');
    else
    this.IdLogin =localStorage.getItem('idlogin_regis');
    user_book.book_id = this.bookdetail;
    user_book.user_email= this.IdLogin;
    if(this.IdLogin){
      if(user_book.count<"1" ||user_book.count>"10"){
        this.messfail=true
        setTimeout(() => this.messfail=false, 3000); 
      }else{
       
        this._userService.get_UserBook_byBookId(user_book.book_id)
        .subscribe(res => { console.log(res);  
     console.log(user_book.count);
     this.user_books=res;
       
          if(res.length==0){   //neu chua co trong gio
            
            this._userService.postBuyBook(user_book)
            .subscribe(resNewUserBook =>{ 
              this.showSucessMessage = true;
              setTimeout(() => this.showSucessMessage = false, 4000); 
              console.log(resNewUserBook)
           
            });
           }else
           {
            var kiemtra1 =false;
            for(let i of this.user_books)
            {
              // neu co trong gio (va chua thanh toan) (kiemtra1)
              if(i.bill=='0')
              {
                user_book._id=i._id;
                user_book.count =(parseInt(i.count)+parseInt(user_book.count)).toString() ;
                 console.log(user_book);
                this._bookService.UpdateUser_book(user_book)
                .subscribe(resDeletedBook =>{
                  this.showSucessMessage = true;
                  setTimeout(() => this.showSucessMessage = false, 4000); 
                  

              });
              kiemtra1=true;
              break;
              }            
            }

     //   neu co trong gio (va da thanh toan)
            if(kiemtra1==false)
            {
              this._userService.postBuyBook(user_book)
              .subscribe(resNewUserBook =>{ 
                this.showSucessMessage = true;
                setTimeout(() => this.showSucessMessage = false, 4000); 
                console.log(resNewUserBook)
             
              });
            }
            }
      
        
        });
    
  }
  }else{
    this._router.navigate(['/login']);
  }
}

}
