import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { BookCenterComponent } from './book-center/book-center.component';
import { CategoryCenterComponent } from './category-center/category-center.component';
import { LoginComponent} from './login/login.component';
import { BagComponent} from './bag/bag.component';
import { ProfileComponent} from './profile/profile.component';
import { BuyBookComponent } from './buy-book/buy-book.component';
import { UserComponent } from './user/user.component';
import { SignUpComponent } from './user/sign-up/sign-up.component';
import { HistoryComponent} from './history/history.component';
const routes: Routes = [
  {path:'',redirectTo:'/home',pathMatch:'full'},
  {path:'home',component:HomeComponent},
  {path:'book',component:BookCenterComponent},
  {path:'category',component:CategoryCenterComponent},
  {path:'book_detail',component:BuyBookComponent},
  {path:'login',component:LoginComponent},
  {path:'bag',component:BagComponent},
  {path:'profile',component:ProfileComponent},
  {path:'history',component:HistoryComponent},
  {
    path:'register',component:UserComponent,
      children: [{ path: '', component: SignUpComponent }]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers:[]
})
export class AppRoutingModule { }
