import { Component, OnInit } from '@angular/core';
import { BookService } from '../book.service';
import { Book } from '../book';
import { CategoryService } from '../shared/category.service';
import { Category } from '../shared/category.model';
import { NgForm } from '@angular/forms';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  providers:[BookService,CategoryService]
})
export class HomeComponent implements OnInit {
  categories: Array<Category>;
  categoriesfilter: Array<Category>;
  books: Array<Book>;
  constructor(private _bookService:BookService,private _categoryService:CategoryService) { }

  ngOnInit() {
    this._bookService.getBooks()
    .subscribe(resBookData => {console.log(resBookData);this.books = resBookData;
      this._categoryService.getCategories()
      .subscribe(resCategoryData => {console.log(resCategoryData);this.categories = resCategoryData});
    });
  
  }
  getid_book(id){
    localStorage.setItem('book_detail',id);
   
  }
  getAllBook(){
    this._bookService.getBooks()
    .subscribe(resBookData => {console.log(resBookData);this.books = resBookData;});
  }
  gettypeCategory(id){
    this._bookService.getBookByCategory(id)
    .subscribe(resCategoryData => {console.log(resCategoryData);this.books = resCategoryData;});
  }
}
