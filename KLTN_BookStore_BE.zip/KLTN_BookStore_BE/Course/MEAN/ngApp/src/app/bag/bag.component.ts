import { Component, OnInit } from '@angular/core';
import { BookService } from '../book.service';
import { Book } from '../book';
import { Router, NavigationExtras } from '@angular/router';
import { User_Book } from '../shared/user_book.model';
import { Type } from '@angular/compiler';
import { NgForm } from '@angular/forms';
import { SendMailService} from '../shared/sendMail.service';
import { User } from '../shared/user.model';
import { SendMail } from '../shared/sendmail.model';

@Component({
  selector: 'app-bag',
  templateUrl: './bag.component.html',
  styleUrls: ['./bag.component.css'],
  providers:[BookService]
})
export class BagComponent implements OnInit {
  IdLogin =localStorage.getItem('IdUserLogin');
  user_books: Array<User_Book> = new Array<User_Book>();
  books : Array<Book> = new Array<Book>();
  Total : number;
  count: number;
  public now: Date = new Date();
  constructor(private _bookService:BookService,private _router:Router,private _sendMailService:SendMailService) { }

  ngOnInit() {
    var k = 0;
    if(localStorage.getItem('IdUserLogin'))
    this.IdLogin =localStorage.getItem('IdUserLogin');
    else
    this.IdLogin =localStorage.getItem('idlogin_regis');
    if(this.IdLogin){
    this.count=0;
    this._bookService.get_UserBook(this.IdLogin)
    .subscribe(resBookData => { 
      this.user_books = resBookData;
       sessionStorage.setItem('user_book',JSON.stringify(resBookData));
       this._bookService.getBooks()
    .subscribe(resBookData => {
      this.books = resBookData;
      sessionStorage.setItem('books',JSON.stringify(resBookData));
      this.Total=0;
 
      for(let i of this.user_books){
        for(let j of this.books){
          if(i.book_id == j._id)
          {
            if(i.bill=='0'){
              this.Total += parseInt(i.count)*j.price;
            }

          }
        }
      }
    });
      });
    
   

   
    
    }else{
      this._router.navigate(['/login']);
    }
    // window.location.reload();
  }
  
  
  getid_book(id){
    localStorage.setItem('book_detail',id);
  }
  idUser_book="";
  getIdUser_book(id){
    this.idUser_book=id;
  }
  UpdateUser_Book(user_book:User_Book){
    user_book._id=this.idUser_book;
    console.log(user_book);
    this._bookService.UpdateUser_book(user_book)
      .subscribe(resDeletedBook =>{
        window.location.reload();
      });
      
    }
  deleteUserBook(id){

 
  this._bookService.deleteUserBook(id)
    .subscribe(resDeletedBook =>{
      window.location.reload();
    });
    
  }
 
  sendmailclick=false;
  sendmailclick2=false;
  SendMail_BuyKT(){
    this.sendmailclick=true;
  }

 errsendMail="";
 ktTotal=false;
  SendMail_Buy(sendMail:SendMail){
    this.sendmailclick2=true;
    
    this.Total=0;
    var dem=0;
    sendMail.name="";
    sendMail.url="";
    sendMail.count="";
  
    sendMail.price ="";
    for(let i of this.user_books){
      for(let j of this.books){
        if(i.book_id == j._id)
        {
         if(i.bill=='0') {
          this.Total += parseInt(i.count)*j.price;
          sendMail.name +=j.name +"next";
          sendMail.url += j.url +"next";
          sendMail.count += i.count +"next";
          sendMail.price +=j.price +"next";

      }
        }
      }
    }

if(this.Total!=0){
    sendMail.total=this.Total;
    sendMail.fullName = localStorage.getItem('Namesession');

  //sendmail      -->>>>>>send mail nè
    this._sendMailService.SendMail_Buy(sendMail)
    .subscribe(res=>{
     
      this.errsendMail=res.toString();
   
      setTimeout(() => this.errsendMail="", 3000); 
      if(this.errsendMail=="Email has been sent--Buy Success"){  
        
        //chuyển các sách từ bag-->history
        this.now = new Date();
        for(let i of this.user_books){
          for(let j of this.books){
            if(i.book_id == j._id)
            {
             if(i.bill=='0') {
             
            //update bill
       
            i.time_buy=this.now.toString().substring(0,24);
            this._bookService.Update_user_book_buybyemail(i)     //>>>>>update value của cột bill
            .subscribe(res=>{
              console.log("bill update");
            });
          }
            }
          }
        }
        //tạo bảng user_book_time

    

        setTimeout(() =>  window.location.reload(), 3000); 
      }
    
    }
    )
  }else{
  this.ktTotal=true;
  }
}
}
