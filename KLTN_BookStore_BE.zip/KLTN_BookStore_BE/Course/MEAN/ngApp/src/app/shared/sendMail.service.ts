import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Http ,Response ,Headers,RequestOptions } from '@angular/http';

import { User } from './user.model';
import { User_Book } from './user_book.model';
import { Book } from '../book';
import { SendMail } from './sendmail.model';
@Injectable({
  providedIn: 'root'
})
export class SendMailService {


  constructor(private http: HttpClient ,private _http: Http) { }

  private _sendmail = "/api/send";

  SendMail_Buy(sendMail:SendMail){
    
    return this.http.post(this._sendmail,sendMail);
  }


  

}




