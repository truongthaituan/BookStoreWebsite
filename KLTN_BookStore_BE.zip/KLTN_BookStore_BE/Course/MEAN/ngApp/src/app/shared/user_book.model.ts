export class User_Book {
    _id:String;
    book_id: String;
    user_email: String;
    count: string;
    bill: String;
    time_buy:String;
}
