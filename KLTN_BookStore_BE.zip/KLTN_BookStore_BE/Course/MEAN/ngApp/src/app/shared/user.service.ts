import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Http ,Response ,Headers,RequestOptions } from '@angular/http';

import { User } from './user.model';
import { User_Book } from './user_book.model';
@Injectable({
  providedIn: 'root'
})
export class UserService {
  selectedUser: User = {
    _id:'',
    fullName: '',
    email: '',
    password: ''

  };
  private _getUrl ="/api/users";
  private _getToLogin ="/api/users/login";
  private _updateUser="/api/users/";
  private _getAPerson ="/api/users/";
  constructor(private http: HttpClient ,private _http: Http) { }

  postUser(user: User){
   
    return this.http.post(this._getUrl,user);
  }

  loginUser(user : User){
    
    return this.http.post(this._getToLogin,user);
  }

  UpdateUser(user: User){
    // return this.http.post(this._updateUser+user._id,user);

    let headers = new Headers ({'Content-Type':'application/json'});
    let options= new RequestOptions({headers:headers});
    return this._http.put(this._updateUser + user._id,JSON.stringify(user),options)
    .map((response:Response)=>response.json());
  }
  
  GetUser(id){
    return this._http.get(this._getAPerson+id)
    .map((response:Response) => response.json());
  }

 
  




  // selectedUser_Book: User_Book = {
  //   _id:'',
  //   book_id: '',
  //   user_email: '',
  //   count: '',
  //   bill:''
  // };

  private buy_book ="/api/user_book";
  private get_user_book="/api/user_book/";
  private get_user_book_byBookId="/api/user_book/bookId/";

  postBuyBook(user_book: User_Book){
   
    return this.http.post(this.buy_book,user_book);
  }

  get_UserBook(id){
    return this.http.get(this.get_user_book+id)
    .map((response:Response) => response.json());
  }
  get_UserBook_byBookId(id){
    return this._http.get(this.get_user_book_byBookId+id)
    .map((response:Response) => response.json());
  }
  

}




