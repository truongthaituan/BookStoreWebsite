import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import { Http ,Response ,Headers,RequestOptions } from '@angular/http';
import { Category } from './category.model';

@Injectable()
export class CategoryService {

    private _getUrl ="/api/categories";
    private _postUrl="/api/categories";
    private _putUrl ="/api/categories/";
    private _deleteUrl ="/api/categories/";
  
    private _getcategorybyId ="/api/categories/";
  constructor(private _http: Http) { }

  getCategories(){
   return this._http.get(this._getUrl)
    .map((response:Response) => response.json());
  }

  addCategory(category:Category){
    let headers = new Headers ({'Content-Type':'application/json'});
    let options= new RequestOptions({headers:headers});
    return this._http.post(this._postUrl,JSON.stringify(category),options)
    .map((response:Response)=>response.json());
  }

  updateCategory(category:Category){
    let headers = new Headers ({'Content-Type':'application/json'});
    let options= new RequestOptions({headers:headers});
    return this._http.put(this._putUrl + category._id,JSON.stringify(category),options)
    .map((response:Response)=>response.json());
  }

  delete(category:Category){
    return this._http.delete(this._deleteUrl+category._id)
    .map((response:Response)=>response.json());
  }
  
  getById(id){
    return this._http.get(this._getcategorybyId+id)
    .map((response:Response) => response.json());
  }




}

