export class Category {
    _id:String;
    categoryName: string; 
}
