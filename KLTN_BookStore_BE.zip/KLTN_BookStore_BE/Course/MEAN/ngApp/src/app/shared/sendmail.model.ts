
export class SendMail{
   
    fullName: string;
    email: string; 
    password: string;
    total: number;
    
    name:String;
    url: String;
    price:String;
    count: string;
    
  
     
}