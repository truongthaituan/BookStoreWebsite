export class User {
    _id:String;
    fullName: string;
    email: string; 
    password: string;
}
