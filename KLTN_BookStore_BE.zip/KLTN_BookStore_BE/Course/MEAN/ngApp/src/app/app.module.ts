import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { BookCenterComponent } from './book-center/book-center.component';
import { BookListComponent } from './book-list/book-list.component';
import { BookDetailComponent } from './book-detail/book-detail.component';
import { HttpModule } from '@angular/http';
import { SafePipe } from './safe.pipe';
import { LoginComponent } from './login/login.component';

import { HttpClientModule } from '@angular/common/http';
import { UserComponent } from './user/user.component';
import { SignUpComponent } from './user/sign-up/sign-up.component';
import {SocialLoginModule,AuthServiceConfig, GoogleLoginProvider,FacebookLoginProvider,LinkedinLoginProvider} from 'ng4-social-login';
import { BuyBookComponent } from './buy-book/buy-book.component';
import { BagComponent } from './bag/bag.component';
import { ProfileComponent } from './profile/profile.component';

import { CategoryDetailComponent } from './category-detail/category-detail.component';
import { CategoryCenterComponent } from './category-center/category-center.component';
import { CategoryListComponent } from './category-list/category-list.component';
import { HistoryComponent } from './history/history.component';


const config = new AuthServiceConfig([
  {
    id: GoogleLoginProvider.PROVIDER_ID,
    provider: new GoogleLoginProvider('178237691815-nab25km4lerfah5upmu3jktqcjc4mprf.apps.googleusercontent.com')
  },
  {
    id: FacebookLoginProvider.PROVIDER_ID,
    provider: new FacebookLoginProvider('392799368262799')
  }
], false);

export function provideConfig(){
  return config;
}



@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    BookCenterComponent,
    BookListComponent,
    BookDetailComponent,
    SafePipe,
    LoginComponent,
   
    UserComponent,
    SignUpComponent,
    BuyBookComponent,
    BagComponent,
    ProfileComponent,
   
    CategoryDetailComponent,
    CategoryCenterComponent,
    CategoryListComponent,
    HistoryComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpModule,
    HttpClientModule,
    ReactiveFormsModule,
    SocialLoginModule
  ],
  providers: [{provide: AuthServiceConfig ,useFactory : provideConfig}],
  bootstrap: [AppComponent]
})
export class AppModule { }
