import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Http ,Response ,Headers,RequestOptions } from '@angular/http';
import { Book } from './book';
import { User_Book } from './shared/user_book.model';

@Injectable()
export class BookService {

  private _getUrl ="/api/books";
  private _postUrl="/api/books";
  private _putUrl ="/api/books/";
  private _deleteUrl ="/api/books/";
  private _getbookbyCategory ="/api/books/findbycategory/";
  private _getbookbyId ="/api/books/";
  constructor(private http: HttpClient ,private _http: Http) { }

  getBooks(){
   return this._http.get(this._getUrl)
    .map((response:Response) => response.json());
  }

  addBook(book:Book){
    let headers = new Headers ({'Content-Type':'application/json'});
    let options= new RequestOptions({headers:headers});
    return this._http.post(this._postUrl,JSON.stringify(book),options)
    .map((response:Response)=>response.json());
  }

  updateBook(book:Book){
    let headers = new Headers ({'Content-Type':'application/json'});
    let options= new RequestOptions({headers:headers});
    return this._http.put(this._putUrl + book._id,JSON.stringify(book),options)
    .map((response:Response)=>response.json());
  }

  deleteBook(book:Book){
    return this._http.delete(this._deleteUrl+book._id)
    .map((response:Response)=>response.json());
  }
  
  getBookById(id){
    return this._http.get(this._getbookbyId+id)
    .map((response:Response) => response.json());
  }
  getBookByCategory(id){
    return this._http.get(this._getbookbyCategory+id)
    .map((response:Response) => response.json());
  }




  private get_user_book="/api/user_book/";
  private deleteUser_book="/api/user_book/";
  private update_user_book="/api/user_book/";
  private user_book_buybyemail="/api/user_book/buy/";

  get_UserBook(id){
    return this._http.get(this.get_user_book+id)
    .map((response:Response) => response.json());
  }
  deleteUserBook(id){
    return this._http.delete(this.deleteUser_book+id)
    .map((response:Response)=>response.json());
  }
  UpdateUser_book(user_book: User_Book){
    let headers = new Headers ({'Content-Type':'application/json'});
    let options= new RequestOptions({headers:headers});
    return this._http.put(this.update_user_book + user_book._id,JSON.stringify(user_book),options)
    .map((response:Response)=>response.json());
  }

  Update_user_book_buybyemail(user_book: User_Book){
    let headers = new Headers ({'Content-Type':'application/json'});
    let options= new RequestOptions({headers:headers});
    return this._http.put(this.user_book_buybyemail + user_book._id,JSON.stringify(user_book),options)
    .map((response:Response)=>response.json());
  }
  




}

