import { Component, OnInit } from '@angular/core';
import { Book } from '../book';
import { BookService } from '../book.service';
import { CategoryService } from '../shared/category.service';
import { Category } from '../shared/category.model';

@Component({
  selector: 'app-book-center',
  templateUrl: './book-center.component.html',
  styleUrls: ['./book-center.component.css'],
  providers:[BookService,CategoryService]
})
export class BookCenterComponent implements OnInit {

  books: Array<Book>;
  categories : Array<Category>;
  selectedBook:Book;
  hidenewBook:boolean =true;
  constructor(private _bookService:BookService,private _categoryService:CategoryService) { }
  updateoke=false
  deleteoke=false
 
  ngOnInit() {
    this._bookService.getBooks()
    .subscribe(resBookData => {this.books = resBookData});
    this._categoryService.getCategories()
    .subscribe(resCategoryData => {this.categories = resCategoryData});
  }

  onSelectBook(book:any){
    this.selectedBook=book;
    this.hidenewBook=true;
   
    this.updateoke=false
    this.deleteoke=false
  }
  onSubmitAddBook(book:Book){
    this._bookService.addBook(book)
    .subscribe(resNewBook =>{
      this.books.push(resNewBook);
      this.selectedBook=resNewBook;
      this.hidenewBook=true;
    });
  }
  onUpdateBookEvent(book:any){
    this._bookService.updateBook(book)
    .subscribe(resUpdateBook => book = resUpdateBook);
    this.selectedBook  = null;
    this.updateoke=true
  }

  onDeleteBookEvent  (book:any){
    let bookArray=this.books;
    this._bookService.deleteBook(book)
    .subscribe(resDeletedBook =>{
      for(let i=0;i<bookArray.length;i++)
      {
        if(bookArray[i]._id === book._id){
          bookArray.splice(i,1);
        }
      }
    });
    this.selectedBook=null;
    this.deleteoke=true
  }
  newBook(){
    this.hidenewBook=false;
    this.updateoke=false
    this.deleteoke=false
  }
  selectChangeHandler (event: any) {
    //update the ui
    // this.book.category = event.target.value;
 
  }
}
