import { Component, OnInit ,EventEmitter} from '@angular/core';


@Component({
  selector: 'book-detail',
  templateUrl: './book-detail.component.html',
  styleUrls: ['./book-detail.component.css'],
  inputs:['book','categories'],
  outputs:['updateBookEvent','deleteBookEvent']
})
export class BookDetailComponent implements OnInit {
  book: any;
  editName:boolean=false;
  editCategory:boolean=false;
  editActor:boolean=false;
  editPrice:boolean=false;
  editUrl:boolean=false;
  updateBookEvent= new EventEmitter();
  deleteBookEvent= new EventEmitter();
  

  
  onNameClick(){
    this.editName=true;
    
  }
  onCategoryClick(){
    this.editCategory=true;
  }
  onActorClick(){
    this.editActor=true;
  }
  onPriceClick(){
    this.editPrice=true;
  }
  onUrlClick(){
    this.editUrl=true;
  }
  ngOnChanges(){
    this.editName=false;
    this.editCategory=false;
    this.editActor=false;
    this.editUrl=false;
    this.editPrice=false;
  }
  constructor() { }

  ngOnInit() {
   
  }

  selectChangeHandler (event: any) {
    //update the ui
    this.book.category = event.target.value;
 
  }
  updateBook(){
  
    this.updateBookEvent.emit(this.book);
  }
  deleteBook(){
    this.deleteBookEvent.emit(this.book);
  }


}

