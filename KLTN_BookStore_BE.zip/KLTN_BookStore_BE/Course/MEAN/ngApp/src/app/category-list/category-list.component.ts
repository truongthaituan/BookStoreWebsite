import { Component, OnInit ,EventEmitter} from '@angular/core';
import { Category } from '../shared/category.model';

@Component({
  selector: 'category-list',
  templateUrl: './category-list.component.html',
  styleUrls: ['./category-list.component.css'],
  inputs:['categories'],
  outputs:['SelectCategory']
})
export class CategoryListComponent implements OnInit {

  public SelectCategory = new EventEmitter();
  constructor() { }

  ngOnInit() {
  }

  onSelect(vid: Category){
    this.SelectCategory.emit(vid);
    
  }

}
