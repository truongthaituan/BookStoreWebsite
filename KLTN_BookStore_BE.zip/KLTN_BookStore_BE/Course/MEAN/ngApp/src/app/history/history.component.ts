import { Component, OnInit } from '@angular/core';
import { BookService } from '../book.service';
import { Book } from '../book';
import { Router, NavigationExtras } from '@angular/router';
import { User_Book } from '../shared/user_book.model';
import { Type } from '@angular/compiler';
import { NgForm } from '@angular/forms';
import { SendMailService} from '../shared/sendMail.service';
import { User } from '../shared/user.model';
import { SendMail } from '../shared/sendmail.model';
@Component({
  selector: 'app-history',
  templateUrl: './history.component.html',
  styleUrls: ['./history.component.css'],
  providers:[BookService]
})
export class HistoryComponent implements OnInit {
  IdLogin =localStorage.getItem('IdUserLogin');
  user_books: Array<User_Book> = new Array<User_Book>();
  books : Array<Book> = new Array<Book>();
  Total : number;
  count: number;
  times: any ="";
  constructor(private _bookService:BookService,private _router:Router,private _sendMailService:SendMailService) { }

  ngOnInit() {


    if(localStorage.getItem('IdUserLogin'))
    this.IdLogin =localStorage.getItem('IdUserLogin');
    else
    this.IdLogin =localStorage.getItem('idlogin_regis');
    if(this.IdLogin){
    this.count=0;
    this._bookService.get_UserBook(this.IdLogin)
    .subscribe(resBookData => { 
      this.user_books = resBookData;
       sessionStorage.setItem('user_book',JSON.stringify(resBookData));
       this._bookService.getBooks()
    .subscribe(resBookData => {
      this.books = resBookData;
      sessionStorage.setItem('books',JSON.stringify(resBookData));
      this.Total=0;
 
      for(let i of this.user_books){
        for(let j of this.books){
          if(i.book_id == j._id)
          {
            if(i.bill=='1'){
              if(this.times.indexOf(i.time_buy)==-1)
              this.times = this.times + i.time_buy + "next";
              this.Total += parseInt(i.count)*j.price;
            }
          }
        }
      }
     
    });
      });
    }else{
      this._router.navigate(['/login']);
    }
    // window.location.reload();
  }
  
  
  
 

  //xử lý date time 
  date_time(){

  }


}