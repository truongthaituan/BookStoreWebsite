import { Component, OnInit ,EventEmitter} from '@angular/core';


@Component({
  selector: 'category-detail',
  templateUrl: './category-detail.component.html',
  styleUrls: ['./category-detail.component.css'],
  inputs:['category'],
  outputs:['updateCategoryEvent','deleteCategoryEvent']
})
export class CategoryDetailComponent implements OnInit {

  category: any;
  editName:boolean=false;
  editCategory:boolean=false;
 
  updateCategoryEvent= new EventEmitter();
  deleteCategoryEvent= new EventEmitter();
  onNameClick(){
    this.editName=true;
  }
  onCategoryClick(){
    this.editCategory=true;
  }
  
  ngOnChanges(){
    this.editName=false;
    this.editCategory=false;
   
  }
  constructor() { }

  ngOnInit() {
  }

  updateCategory(){
    this.updateCategoryEvent.emit(this.category);
  }
  deleteCategory(){
    this.deleteCategoryEvent.emit(this.category);
  }
}
