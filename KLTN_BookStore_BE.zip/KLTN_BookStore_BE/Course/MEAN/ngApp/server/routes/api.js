const express = require('express');
// const router = express.Router();
const mongoose = require('mongoose');
//Controller
//A_store
const book = require('../controllers/A_store/bookController');
const category = require('../controllers/A_store/categoryController');
const author = require('../controllers/A_store/authorController');
const nxb = require('../controllers/A_store/nxbCategory');
const seri = require('../controllers/A_store/seriCategory');

//B_profile
const customer = require('../controllers/B_profile/customerController');
const employee = require('../controllers/B_profile/employeeController');
var app = express();
mongoose.set('createIndexes', true);
mongoose.connect('mongodb://localhost:27017/dbBook', {
    useNewUrlParser: true,
    useUnifiedTopology: true
});
//C_permission
//D_action
//E_payment
//F_event
//G_recommentSys
//H_tracking
//end controller

//app
//A_store
app.use('/', book);
app.use('/', category);
app.use('/', author);
app.use('/', nxb);
app.use('/', seri);
//B_profile
app.use('/', customer);
app.use('/', employee);
//C_permission
//D_action
//E_payment
//F_event
//G_recommentSys
//H_tracking
module.exports = app;