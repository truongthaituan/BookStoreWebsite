const express = require('express');
const router = express.Router();
const promotion = require('../../models/F_event/promotion');
//promotion
//get all
router.get('/promotions', function(req, res) {
    console.log('get request for all promotions');
    promotion.find({})
        .exec(function(err, promotions) {
            if (err) {
                console.log("err req promotions");
            } else {
                res.json(promotions);
            }
        });
});

// get a person
router.get('/promotions/:promotionID', function(req, res) {
    promotion.findById(req.params.promotionID)
        .exec(function(err, promotions) {
            if (err) console.log("Error retrieving promotion");
            else res.json(promotions);
        });
})

//post
router.post('/promotions', function(req, res) {
    var newpromotion = new promotion();
    newpromotion.Namepromotion = req.body.Namepromotion;

    newpromotion.save(function(err, insertedpromotion) {
        if (err) {
            console.log('Err Saving promotion');
        } else {
            res.json(insertedpromotion);
        }
    });
});


//update
router.put('/promotions/:id', function(req, res) {
        promotion.findByIdAndUpdate(req.params.id, {
                $set: {
                    Namepromotion: req.body.Namepromotion,

                }
            }, {
                new: true
            },
            function(err, updatedpromotion) {
                if (err) {
                    res.send("err Update");
                } else {
                    res.json(updatedpromotion);
                }
            })
    })
    //delete
router.delete('/promotions/:id', function(req, res) {
    promotion.findByIdAndRemove(req.params.id, function(err, deletepromotion) {
        if (err) {
            res.send('err Delete');
        } else {
            res.json(deletepromotion);
        }
    });
});
module.exports = router;