const express = require('express');
const router = express.Router();
const discountCode = require('../../models/F_event/discountCode');
//discountCode
//get all
router.get('/discountCodes', function(req, res) {
    console.log('get request for all discountCodes');
    discountCode.find({})
        .exec(function(err, discountCodes) {
            if (err) {
                console.log("err req discountCodes");
            } else {
                res.json(discountCodes);
            }
        });
});

// get a person
router.get('/discountCodes/:discountCodeID', function(req, res) {
    discountCode.findById(req.params.discountCodeID)
        .exec(function(err, discountCodes) {
            if (err) console.log("Error retrieving discountCode");
            else res.json(discountCodes);
        });
})

//post
router.post('/discountCodes', function(req, res) {
    var newdiscountCode = new discountCode();
    newdiscountCode.DiscountDetail = req.body.DiscountDetail;
    newdiscountCode.DateStart = req.body.DateStart;
    newdiscountCode.DateEnd = req.body.DateEnd;
    newdiscountCode.Check = req.body.Check;
    newdiscountCode.Discount = req.body.Discount;

    newdiscountCode.save(function(err, inserteddiscountCode) {
        if (err) {
            console.log('Err Saving discountCode');
        } else {
            res.json(inserteddiscountCode);
        }
    });
});


//update
router.put('/discountCodes/:id', function(req, res) {
        discountCode.findByIdAndUpdate(req.params.id, {
                $set: {
                    DiscountDetail: req.body.DiscountDetail,
                    DateStart: req.body.DateStart,
                    DateEnd: req.body.DateEnd,
                    Check: req.body.Check,
                    Discount: req.body.Discount,

                }
            }, {
                new: true
            },
            function(err, updateddiscountCode) {
                if (err) {
                    res.send("err Update");
                } else {
                    res.json(updateddiscountCode);
                }
            })
    })
    //delete
router.delete('/discountCodes/:id', function(req, res) {
    discountCode.findByIdAndRemove(req.params.id, function(err, deletediscountCode) {
        if (err) {
            res.send('err Delete');
        } else {
            res.json(deletediscountCode);
        }
    });
});
module.exports = router;