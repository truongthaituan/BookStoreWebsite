const express = require('express');
const router = express.Router();
const user = require('../../models/C_permission/user');
//user
//get all
router.get('/users', function(req, res) {
    console.log('get request for all users');
    user.find({})
        .exec(function(err, users) {
            if (err) {
                console.log("err req users");
            } else {
                res.json(users);
            }
        });
});

// get a person
router.get('/users/:userID', function(req, res) {
    user.findById(req.params.userID)
        .exec(function(err, users) {
            if (err) console.log("Error retrieving user");
            else res.json(users);
        });
})

//post
router.post('/users', function(req, res) {
    var newuser = new user();
    newuser.UserName = req.body.UserName;
    newuser.Password = req.body.Password;
    newuser.RoleID = req.body.RoleID;

    newuser.save(function(err, inserteduser) {
        if (err) {
            console.log('Err Saving user');
        } else {
            res.json(inserteduser);
        }
    });
});


//update
router.put('/users/:id', function(req, res) {
        user.findByIdAndUpdate(req.params.id, {
                $set: {
                    UserName: req.body.UserName,
                    Password: req.body.Password,
                    RoleID: req.body.RoleID,

                }
            }, {
                new: true
            },
            function(err, updateduser) {
                if (err) {
                    res.send("err Update");
                } else {
                    res.json(updateduser);
                }
            })
    })
    //delete
router.delete('/users/:id', function(req, res) {
    user.findByIdAndRemove(req.params.id, function(err, deleteuser) {
        if (err) {
            res.send('err Delete');
        } else {
            res.json(deleteuser);
        }
    });
});
module.exports = router;