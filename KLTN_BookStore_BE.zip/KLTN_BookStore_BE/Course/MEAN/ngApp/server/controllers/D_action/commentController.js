const express = require('express');
const router = express.Router();
const comment = require('../../models/D_action/comment');
//comment
//get all
router.get('/comments', function(req, res) {
    console.log('get request for all comments');
    comment.find({})
        .exec(function(err, comments) {
            if (err) {
                console.log("err req comments");
            } else {
                res.json(comments);
            }
        });
});

// get a person
router.get('/comments/:commentID', function(req, res) {
    comment.findById(req.params.commentID)
        .exec(function(err, comments) {
            if (err) console.log("Error retrieving comment");
            else res.json(comments);
        });
})

//post
router.post('/comments', function(req, res) {
    var newcomment = new comment();
    newcomment.BookID = req.body.BookID;
    newcomment.UserID = req.body.UserID;
    newcomment.CommentDate = req.body.CommentDate;
    newcomment.Time = req.body.Time;
    newcomment.Content = req.body.Content;

    newcomment.save(function(err, insertedcomment) {
        if (err) {
            console.log('Err Saving comment');
        } else {
            res.json(insertedcomment);
        }
    });
});


//update
router.put('/comments/:id', function(req, res) {
        comment.findByIdAndUpdate(req.params.id, {
                $set: {
                    BookID: req.body.BookID,
                    UserID: req.body.UserID,
                    CommentDate: req.body.CommentDate,
                    Time: req.body.Time,
                    Content: req.body.Content,

                }
            }, {
                new: true
            },
            function(err, updatedcomment) {
                if (err) {
                    res.send("err Update");
                } else {
                    res.json(updatedcomment);
                }
            })
    })
    //delete
router.delete('/comments/:id', function(req, res) {
    comment.findByIdAndRemove(req.params.id, function(err, deletecomment) {
        if (err) {
            res.send('err Delete');
        } else {
            res.json(deletecomment);
        }
    });
});
module.exports = router;