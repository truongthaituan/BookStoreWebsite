const express = require('express');
const router = express.Router();
const customer = require('../../models/B_profile/customer');
//customer
//get all
router.get('/customers', function(req, res) {
    console.log('get request for all customers');
    customer.find({})
        .exec(function(err, customers) {
            if (err) {
                console.log("err req customers");
            } else {
                res.json(customers);
            }
        });
});

// get a person
router.get('/customers/:customerID', function(req, res) {
    customer.findById(req.params.customerID)
        .exec(function(err, customers) {
            if (err) console.log("Error retrieving customer");
            else res.json(customers);
        });
})

//post
router.post('/customers', function(req, res) {
    var newcustomer = new customer();
    newcustomer.UserID = req.body.UserID;
    newcustomer.Name = req.body.Name;
    newcustomer.NickName = req.body.NickName;
    newcustomer.Phone = req.body.Phone;
    newcustomer.Address = req.body.Address;
    newcustomer.Email = req.body.Email;

    newcustomer.save(function(err, insertedcustomer) {
        if (err) {
            console.log('Err Saving customer');
        } else {
            res.json(insertedcustomer);
        }
    });
});


//update
router.put('/customers/:id', function(req, res) {
        customer.findByIdAndUpdate(req.params.id, {
                $set: {
                    UserID: req.body.UserID,
                    Name: req.body.Name,
                    NickName: req.body.NickName,
                    Phone: req.body.Phone,
                    Address: req.body.Address,
                    Email: req.body.Email,

                }
            }, {
                new: true
            },
            function(err, updatedcustomer) {
                if (err) {
                    res.send("err Update");
                } else {
                    res.json(updatedcustomer);
                }
            })
    })
    //delete
router.delete('/customers/:id', function(req, res) {
    customer.findByIdAndRemove(req.params.id, function(err, deletecustomer) {
        if (err) {
            res.send('err Delete');
        } else {
            res.json(deletecustomer);
        }
    });
});
module.exports = router;