const express = require('express');
const router = express.Router();
const employee = require('../../models/B_profile/employee');
//employee
//get all
router.get('/employees', function(req, res) {
    console.log('get request for all employees');
    employee.find({})
        .exec(function(err, employees) {
            if (err) {
                console.log("err req employees");
            } else {
                res.json(employees);
            }
        });
});

// get a person
router.get('/employees/:employeeID', function(req, res) {
    employee.findById(req.params.employeeID)
        .exec(function(err, employees) {
            if (err) console.log("Error retrieving employee");
            else res.json(employees);
        });
})

//post
router.post('/employees', function(req, res) {
    var newemployee = new employee();
    newemployee.UserID = req.body.UserID;
    newemployee.NameEmp = req.body.NameEmp;
    newemployee.Phone = req.body.Phone;
    newemployee.Address = req.body.Address;
    newemployee.NickName = req.body.NickName;
    newemployee.Email = req.body.Email;
    newemployee.Male = req.body.Male;
    newemployee.DateOfBirth = req.body.DateOfBirth;
    newemployee.save(function(err, insertedemployee) {
        if (err) {
            console.log('Err Saving employee');
        } else {
            res.json(insertedemployee);
        }
    });
});


//update
router.put('/employees/:id', function(req, res) {
        employee.findByIdAndUpdate(req.params.id, {
                $set: {
                    UserID: req.body.UserID,
                    NameEmp: req.body.NameEmp,
                    Phone: req.body.Phone,
                    Address: req.body.Address,
                    NickName: req.body.NickName,
                    Email: req.body.Email,
                    Male: req.body.Male,
                    DateOfBirth: req.body.DateOfBirth,
                }
            }, {
                new: true
            },
            function(err, updatedemployee) {
                if (err) {
                    res.send("err Update");
                } else {
                    res.json(updatedemployee);
                }
            })
    })
    //delete
router.delete('/employees/:id', function(req, res) {
    employee.findByIdAndRemove(req.params.id, function(err, deleteemployee) {
        if (err) {
            res.send('err Delete');
        } else {
            res.json(deleteemployee);
        }
    });
});
module.exports = router;