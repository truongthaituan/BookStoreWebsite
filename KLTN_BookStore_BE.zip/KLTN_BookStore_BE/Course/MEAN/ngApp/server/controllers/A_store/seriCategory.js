const express = require('express');
const router = express.Router();
const seri = require('../../models/A_store/seri');
//seri
//get all
router.get('/series', function(req, res) {
    console.log('get request for all series');
    seri.find({})
        .exec(function(err, series) {
            if (err) {
                console.log("err req series");
            } else {
                res.json(series);
            }
        });
});

// get a person
router.get('/series/:seriID', function(req, res) {
    seri.findById(req.params.seriID)
        .exec(function(err, series) {
            if (err) console.log("Error retrieving seri");
            else res.json(series);
        });
})

//post
router.post('/series', function(req, res) {
    var newseri = new seri();
    newseri.SeriName = req.body.SeriName;
    newseri.SeriDetail = req.body.SeriDetail;
    newseri.SeriImg = req.body.SeriImg;
    newseri.save(function(err, insertedseri) {
        if (err) {
            console.log('Err Saving seri');
        } else {
            res.json(insertedseri);
        }
    });
});


//update
router.put('/series/:id', function(req, res) {
        seri.findByIdAndUpdate(req.params.id, {
                $set: {

                    SeriName: req.body.SeriName,
                    SeriDetail: req.body.SeriDetail,
                    SeriImg: req.body.SeriImg,
                }
            }, {
                new: true
            },
            function(err, updatedseri) {
                if (err) {
                    res.send("err Update");
                } else {
                    res.json(updatedseri);
                }
            })
    })
    //delete
router.delete('/series/:id', function(req, res) {
    seri.findByIdAndRemove(req.params.id, function(err, deleteseri) {
        if (err) {
            res.send('err Delete');
        } else {
            res.json(deleteseri);
        }
    });
});
module.exports = router;