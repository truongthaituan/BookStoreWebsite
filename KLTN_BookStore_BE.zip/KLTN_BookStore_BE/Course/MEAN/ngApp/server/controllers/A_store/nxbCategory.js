const express = require('express');
const router = express.Router();
const nxb = require('../../models/A_store/nxb');
//nxb
//get all
router.get('/nxbs', function(req, res) {
    console.log('get request for all nxbs');
    nxb.find({})
        .exec(function(err, nxbs) {
            if (err) {
                console.log("err req nxbs");
            } else {
                res.json(nxbs);
            }
        });
});

// get a person
router.get('/nxbs/:nxbID', function(req, res) {
    nxb.findById(req.params.nxbID)
        .exec(function(err, nxbs) {
            if (err) console.log("Error retrieving nxb");
            else res.json(nxbs);
        });
})

//post
router.post('/nxbs', function(req, res) {
    var newnxb = new nxb();
    newnxb.NameNXB = req.body.NameNXB;
    newnxb.DetailNXB = req.body.DetailNXB;
    newnxb.ImgNXB = req.body.ImgNXB;
    newnxb.save(function(err, insertednxb) {
        if (err) {
            console.log('Err Saving nxb');
        } else {
            res.json(insertednxb);
        }
    });
});


//update
router.put('/nxbs/:id', function(req, res) {
        nxb.findByIdAndUpdate(req.params.id, {
                $set: {
                    NameNXB: req.body.NameNXB,
                    DetailNXB: req.body.DetailNXB,
                    ImgNXB: req.body.ImgNXB,

                }
            }, {
                new: true
            },
            function(err, updatednxb) {
                if (err) {
                    res.send("err Update");
                } else {
                    res.json(updatednxb);
                }
            })
    })
    //delete
router.delete('/nxbs/:id', function(req, res) {
    nxb.findByIdAndRemove(req.params.id, function(err, deletenxb) {
        if (err) {
            res.send('err Delete');
        } else {
            res.json(deletenxb);
        }
    });
});
module.exports = router;