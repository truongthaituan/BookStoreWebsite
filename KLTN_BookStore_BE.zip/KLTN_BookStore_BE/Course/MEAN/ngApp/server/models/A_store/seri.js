const mongoose=require('mongoose');

const Schema=mongoose.Schema;

const seriSchema = new Schema({

    SeriName:String,
    SeriDetail:String,
    SeriImg:String,

    
    });

module.exports = mongoose.model('seri',seriSchema,'series');