const mongoose=require('mongoose');

const Schema=mongoose.Schema;

const nxbSchema = new Schema({

    NameNXB:String,
    DetailNXB:String,
    ImgNXB:String,
    
    });

module.exports = mongoose.model('nxb',nxbSchema,'nxbs');