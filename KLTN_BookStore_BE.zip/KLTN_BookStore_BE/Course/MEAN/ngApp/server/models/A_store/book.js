 const mongoose = require('mongoose');

 const Schema = mongoose.Schema;

 const bookSchema = new Schema({
     NameBook: String,
     Publish: String,
     CategoryID: String,
     AuthorID: String,
     NxbID: String,
     PriceBook: Number,
     DetailBook: String,
     ImgBook: String,
     SeriID: String,
     Sale: Number,
 });

 module.exports = mongoose.model('book', bookSchema, 'books');