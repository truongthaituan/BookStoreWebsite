const mongoose=require('mongoose');

const Schema=mongoose.Schema;

const authorSchema = new Schema({
    NameAuthor:String,
    DetailAuthor:String,
    ImgAuthor:String,

    });

module.exports = mongoose.model('author',authorSchema,'authors');