const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const commentSchema = new Schema({
    BookID: String,
    UserID: String,
    CommentDate: String,
    Time: String,
    Content: String,
});

module.exports = mongoose.model('comment', commentSchema, 'comments');