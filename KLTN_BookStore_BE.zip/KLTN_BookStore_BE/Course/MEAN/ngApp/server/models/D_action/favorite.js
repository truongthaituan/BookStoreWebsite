const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const favoriteSchema = new Schema({
    BookID: String,
    UserID: String,
});

module.exports = mongoose.model('favorite', favoriteSchema, 'favorites');