const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const ratingSchema = new Schema({
    BookID: String,
    UserID: String,
    Star: Number,

});

module.exports = mongoose.model('rating', ratingSchema, 'ratings');