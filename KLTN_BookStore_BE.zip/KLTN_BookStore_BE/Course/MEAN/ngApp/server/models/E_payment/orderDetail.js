const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const orderDetailSchema = new Schema({
    OrderID: String,
    BookID: String,
    Count: Number,
    Price: Number,

});

module.exports = mongoose.model('orderDetail', orderDetailSchema, 'orderDetails');