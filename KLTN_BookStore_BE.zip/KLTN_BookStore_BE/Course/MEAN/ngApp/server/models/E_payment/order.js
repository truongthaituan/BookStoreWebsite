const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const orderSchema = new Schema({
    CustomerID: String,
    TotalPrice: Number,
    OrderDate: String,

});

module.exports = mongoose.model('order', orderSchema, 'orders');