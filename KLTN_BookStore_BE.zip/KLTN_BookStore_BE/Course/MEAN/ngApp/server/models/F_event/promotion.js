const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const promotionSchema = new Schema({
    DetailPromotion: String,
    Discount: Number,
    IfDiscount: Number,
    StartDate: String,
    EndDate: String,

});

module.exports = mongoose.model('promotion', promotionSchema, 'promotions');