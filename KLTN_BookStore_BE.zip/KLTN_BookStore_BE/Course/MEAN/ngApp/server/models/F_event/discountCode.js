const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const discountCodeSchema = new Schema({
    DiscountDetail: String,
    DateStart: String,
    DateEnd: String,
    Check: Boolean,
    Discount: Number,
});

module.exports = mongoose.model('discountCode', discountCodeSchema, 'discountCodes');