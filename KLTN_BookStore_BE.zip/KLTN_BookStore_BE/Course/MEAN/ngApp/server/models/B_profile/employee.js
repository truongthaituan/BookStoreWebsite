const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const employeeSchema = new Schema({
    UserID: String,
    NameEmp: String,
    Phone: String,
    Address: String,
    NickName: String,
    Email: String,
    Male: String,
    DateOfBirth: String,
});

module.exports = mongoose.model('employee', employeeSchema, 'employees');