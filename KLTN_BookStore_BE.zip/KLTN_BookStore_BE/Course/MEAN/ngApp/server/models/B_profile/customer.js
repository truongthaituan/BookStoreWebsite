const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const customerSchema = new Schema({
    UserID: String,
    Name: String,
    NickName: String,
    Phone: String,
    Address: String,
    Email: String,
});

module.exports = mongoose.model('customer', customerSchema, 'customers');