export class User {
    _id:string;
    email: string;
    fullName: string;
    password: string;
    roleID: string;
}
