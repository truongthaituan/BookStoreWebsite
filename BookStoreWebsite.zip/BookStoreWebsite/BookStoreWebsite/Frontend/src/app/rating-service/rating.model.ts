export class Rating {
    _id:string;
    bookID:string;
    userID: string;
    star: string;
    review: string;
}
