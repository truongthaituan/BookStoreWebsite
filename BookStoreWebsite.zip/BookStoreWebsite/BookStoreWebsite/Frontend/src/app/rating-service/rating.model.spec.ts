import { Rating } from './rating.model';

describe('Rating', () => {
  it('should create an instance', () => {
    expect(new Rating()).toBeTruthy();
  });
});
