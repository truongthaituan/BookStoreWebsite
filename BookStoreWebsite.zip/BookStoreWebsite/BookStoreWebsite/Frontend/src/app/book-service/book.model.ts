export class Book {
     _id: string;
     nameBook: string;
     categoryID: string;     
     authorID: string;
     priceBook: number;
     detailBook: string;
     imgBook: string;
     seriID: string;
     sale: number;
     count: number;
}
