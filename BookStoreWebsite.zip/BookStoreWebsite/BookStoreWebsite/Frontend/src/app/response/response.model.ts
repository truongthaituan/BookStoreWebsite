export class Response {
    status: boolean;
    message: string;
    obj: Object;
    token: string;
}
