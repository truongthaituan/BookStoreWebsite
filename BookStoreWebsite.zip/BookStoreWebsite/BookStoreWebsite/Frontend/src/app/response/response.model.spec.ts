import { Response } from './response.model';

describe('Response', () => {
  it('should create an instance', () => {
    expect(new Response()).toBeTruthy();
  });
});
