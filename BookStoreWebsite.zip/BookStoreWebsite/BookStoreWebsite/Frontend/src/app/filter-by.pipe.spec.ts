import { FilterByPipe } from './filter-by.pipe';

describe('FilterByPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterByPipe();
    expect(pipe).toBeTruthy();
  });
});
