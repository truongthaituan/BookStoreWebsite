import { Author } from './author.model';

describe('Author', () => {
  it('should create an instance', () => {
    expect(new Author()).toBeTruthy();
  });
});
