export class Author {
    _id: String;
    nameAuthor: String;
}
