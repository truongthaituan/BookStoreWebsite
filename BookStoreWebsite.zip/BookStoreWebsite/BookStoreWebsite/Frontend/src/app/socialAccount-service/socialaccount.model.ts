export class Socialaccount {
    _id: string;
    email: string;
    username: string;
    imageUrl: string;
    facebook_id: string;
    google_id: string;
    typeAccount: number;
}
