import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { BookCategoryComponent } from './book-category/book-category.component';
import { BookDetailComponent } from './book-detail/book-detail.component';
import { MyAccountComponent } from './my-account/my-account.component';
import { LostPasswordComponent } from './lost-password/lost-password.component';


const routes: Routes = [
  {path:'', component: HomeComponent},
  {path: 'booksCategory',component: BookCategoryComponent},
  {path: 'bookDetail',component: BookDetailComponent},
  {path: 'account',component: MyAccountComponent},
  {path: 'lostPassword',component: LostPasswordComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
