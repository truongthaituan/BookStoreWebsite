import { Component, OnInit } from '@angular/core';
declare var $:any;
@Component({
  selector: 'app-lost-password',
  templateUrl: './lost-password.component.html',
  styleUrls: ['./lost-password.component.css']
})
export class LostPasswordComponent implements OnInit {

  constructor() {
    $(function(){
      $("#scrollToTopButton").click(function () {
        $("html, body").animate({scrollTop: 0}, 1000);
       });
    });
   }

  ngOnInit() {
  }

}
