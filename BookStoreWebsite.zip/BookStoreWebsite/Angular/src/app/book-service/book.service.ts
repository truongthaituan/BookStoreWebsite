import { Injectable } from '@angular/core';
import { Book } from './book.model';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class BookService {
  selectedBook: Book;
  book: Book[];
  readonly baseURL = 'http://localhost:3000/listBook';
  constructor(private _http: HttpClient) { }
  getBookList() {
    return this._http.get(this.baseURL);
  }
}
