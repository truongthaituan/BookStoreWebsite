export class Book {
    _id: String;
    nameBook: String;
    publish: String;
    categoryID: String;
    authorID: String;
    nxbID: String;
    priceBook: Number;
    detailBook: String;
    imgBook: String;
}
