import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

declare var $:any
@Component({
  selector: 'app-book-category',
  templateUrl: './book-category.component.html',
  styleUrls: ['./book-category.component.css']
})

export class BookCategoryComponent implements OnInit {

  constructor(private _router:Router) { 

    $(function() {
      $( "#slider-range" ).slider({
        range: true,
        min: 0,
        max: 200000,
        values: [0, 50000],
        animate:true,
        step:10000,
        slide: function( event, ui ) {
          $( "#amount-min" ).val( "Min: " + ui.values[ 0 ] + "đ");
          $( "#amount-max" ).val( "Max: " + ui.values[ 1 ] + "đ");
        }
      });
      $( "#amount-min" ).val("Min : " + $( "#slider-range" ).slider( "values", 0 ) + "đ");
      $( "#amount-max" ).val( "Max : " + $( "#slider-range" ).slider( "values", 1 ) + "đ");
      $("#scrollToTopButton").click(function () {
        $("html, body").animate({scrollTop: 0}, 1000);
       });
    });
   
  }

  ngOnInit() {
  }
  moveToBookDetail(){
    return this._router.navigate(["/bookDetail"]);
  }
}
