import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BookService } from '../book-service/book.service';
import { NgForm } from '@angular/forms';
import { Book } from '../book-service/book.model';
import { FormGroup, FormBuilder } from '@angular/forms';
import { CategoryService } from '../category-service/category.service';
import { Category } from '../category-service/category.model';
declare var $:any;
@Component({
  selector: 'app-update-book',
  templateUrl: './update-book.component.html',
  styleUrls: ['./update-book.component.css']
})
export class UpdateBookComponent implements OnInit {
  id_book: string;
  selectedValue = '';
  countryForm: FormGroup;
  categories = [];
  // countries = ['USA', 'Canada', 'Uk']
  constructor(private _router:Router,  private bookService:BookService, 
    private fb: FormBuilder,private categoryService: CategoryService) {
      $(document).ready(function() {
      $(function() {
        // var categories = sessionStorage.getItem('categories');
        // console.log(categories);
      }); 
      });  
     }
  ngOnInit() {
    var id = sessionStorage.getItem('idCategory');
    this.resetForm();
    this.getBookListById('5e588b70f8c7eb3c34faef6f');
    this.getCategoryList();
    // this.getBookCategoryById(id);
    // this.selectedValue = "Sách Kinh Tế";
  }
  resetForm(form?: NgForm) {
    if (form)
      form.reset();
    this.bookService.selectedBook = {
      _id: "",
      nameBook:"",
      publish:"",
      categoryID: "",
      authorID: "",
      nxbID: "",
      priceBook: null,
      detailBook:"",
      imgBook:""
    }
  }
  getBookCategoryById(id:string) {
    this.categoryService.getCategoryById(id).subscribe((res) => {
      this.categoryService.category = res as Category[];
      console.log(res);
    });
  }
  getBookListById(id:string) {
    this.bookService.getBookById(id).subscribe((res) => {
      this.bookService.book = res as Book[];
      console.log(res)
    });
  }
  getCategoryList() {
    this.categoryService.getCategoryList().subscribe((res) => {
		  this.categoryService.category = res as Category[];
		});
	  }
}
