var express = require('express');
var router = express.Router();
var Books = require('../models/books');

router.get('/books', (req,res) => {
    Books.find((err,docs) => {
        if(!err){ res.send(docs);}
        else{
            console.log("Error!");
        }
    })
});
router.get('/books/:book_id', function(req, res){
    Books.findById(req.params.book_id, function(err, doc){
        if (err) return res.send(err);
        // return a message
        res.send(doc); 
    });
});
router.post('/books',(req,res) =>{
    var book = new Books({
        nameBook: req.body.nameBook,
        categoryID: req.body.categoryID,
        authorID: req.body.authorID,
        nxbID: req.body.nxbID,
        priceBook: req.body.priceBook,
        detailBook: req.body.detailBook,
        imgBook: req.body.imgBook,
    });
    book.save((err, doc) => {
        if (err) return res.send(err);
        // return a message
        res.send(doc); 
    });
});

router.put('/books/:book_id',function(req, res) {
    Books.findById(req.params.book_id, function(err, book) {
        if (err) return res.send(err);
        // set the new user information if it exists in the request 
        if (req.body.nameBook) book.nameBook = req.body.nameBook; 
        if (req.body.categoryID) book.categoryID = req.body.categoryID; 
        if (req.body.authorID) book.authorID = req.body.authorID;
        if(req.body.nxbID) book.nxbID = req.body.nxbID;
        if(req.body.priceBook) book.priceBook = req.body.priceBook;
        if(req.body.detailBook) book.detailBook = req.body.detailBook;
        if(req.body.imgBook) book.imgBook = req.body.imgBook;
        // save the user
        book.save(function(err,doc) {
        if (err) return res.send(err);
        // return a message
        res.send(doc); 
        });
    });
});

router.delete('/books/:book_id',function(req, res) {
    Books.remove({
        _id: req.params.book_id
    },function(err, book){
        if(err) return res.send(err);
        res.json({ message: 'Successfully deleted'});
    });
});
module.exports = router;