var express = require('express');
var router = express.Router();
var Books = require('../models/books');

router.get('/listBook', (req,res) => {
    Books.find((err,docs) => {
        if(!err){ res.send(docs);}
        else{
            console.log("Error!");
        }
    })
});
module.exports = router;