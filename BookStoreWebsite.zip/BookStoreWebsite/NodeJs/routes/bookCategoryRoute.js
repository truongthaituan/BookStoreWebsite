var express = require('express');
var router = express.Router();
var Categories = require('../models/bookCategory');

router.get('/categories', (req,res) => {
    Categories.find((err,docs) => {
        if(!err){ res.send(docs);}
        else{
            console.log("Error!");
        }
    })
});
router.get('/categories/:category_id', function(req, res){
    Categories.findById(req.params.category_id, function(err, doc){
        if (err) return res.send(err);
        // return a message
        res.send(doc); 
    });
});
router.post('/categories',(req,res) =>{
    var category = new Categories({
        nameCategory: req.body.nameCategory
    });
    category.save((err, doc) => {
        if (err) return res.send(err);
        // return a message
        res.send(doc); 
    });
});

router.put('/categories/:category_id',function(req, res) {
    Categories.findById(req.params.category_id, function(err, category) {
        if (err) return res.send(err);
        // set the new user information if it exists in the request 
        if (req.body.nameCategory) category.nameCategory = req.body.nameCategory; 
        // save the user
        category.save(function(err,doc) {
        if (err) return res.send(err);
        // return a message
        res.send(doc); 
        });
    });
});

router.delete('/categories/:category_id',function(req, res) {
    Categories.remove({
        _id: req.params.category_id
    },function(err, book){
        if(err) return res.send(err);
        res.json({ message: 'Successfully deleted'});
    });
});
module.exports = router;