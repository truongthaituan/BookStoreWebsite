var mongoose = require('mongoose');
var bookCategorySchema = mongoose.Schema({
    nameCategory: String
});
module.exports = mongoose.model('bookcategories',bookCategorySchema);