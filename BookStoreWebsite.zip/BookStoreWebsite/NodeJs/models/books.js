var mongoose = require('mongoose');
var bookSchema = mongoose.Schema({
    nameBook: String,
    publish: String,
    categoryID: String,
    authorID: String,
    nxbID: String,
    priceBook: Number,
    detailBook: String,
    imgBook: String
});
module.exports = mongoose.model('books',bookSchema);